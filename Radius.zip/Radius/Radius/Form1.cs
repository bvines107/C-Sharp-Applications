﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Radius
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateRadius(object sender, EventArgs e)
        {
            //create instance of calculate 
            var radi = new Calculate();

            //get the user's input and converts string to int w/ int.parse method
            //stores the input in the ven variable
            var ven = int.Parse(radBox.Text);

            //user can only enter in a max of 3 characters
            radBox.MaxLength = 3;
           
            //passes the input to the setRadius method
            radi.SetRadius(ven);

            //outputs the area in a message box 
            MessageBox.Show("The Area is: "+ radi.Area().ToString("00.00")); 
            
        }
        
    }
}
