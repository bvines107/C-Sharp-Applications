﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Radius
{
    class Calculate
    {
        //private member variable radius
        private int radius;

        // sets the radius
        public void SetRadius(int radius)
        {
            this.radius = radius;
        }

        //method to calculate the area
        public double Area()
        {
            return this.radius * this.radius * Math.PI;
        }

    }
}
