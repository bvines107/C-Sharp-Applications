﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvenOrOdd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEvenOddClicked(object sender, EventArgs e)
        {
            // i variable will store the input.
            int i;

            // try statement will catch errors
            try
            {
                // takes the string representation of a number and converts into a value
                i = Convert.ToInt32(txtNumber.Text);

                // if the inputer is disvisble by 2 and the results = 0 then the if statement returns even
                if (i % 2 == 0)
                {
                    lblResult.Text = "Even";
                }

                //else returns ODD
                else
                {
                    lblResult.Text = "Odd";
                }
            }

            // catches and displays an error message if the wrong information is input.
            catch(Exception err)
            {
                MessageBox.Show("Please enter in a number", "Application Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // describes the application 
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("This app tells if the number is even or odd.", "AppInfo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}
