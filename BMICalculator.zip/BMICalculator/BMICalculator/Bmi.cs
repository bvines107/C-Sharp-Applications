﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMICalculator
{
    class Bmi : Scale
    {
        //this method will calculate the BMI
        public float Calculate()
        {
            return 703 * (this.weight / this.height * this.height);
        }
    }
}
