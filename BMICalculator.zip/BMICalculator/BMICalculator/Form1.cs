﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMICalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculations(object sender, EventArgs e)
        {
            //creates an instance of the BMI
            var bimp = new Bmi();

            //takes input from the hght text parse and parses it as a float
            var hght = Single.Parse(hghtTxt.Text);
            //limits the length of characters the user can input
            hghtTxt.MaxLength = 4;

            //takes input from the wght text parse and parses it as a float
            var wght = Single.Parse(wghtTxt.Text);
            //limits the length of characters the user can input
            wghtTxt.MaxLength = 4;

            //passes the users input to the
            bimp.SetMeasurment(wght, hght);

            //passes the measurments to the calculate method and parses the floats back to a string
            //outputs the BMI in a Message Box
            MessageBox.Show(bimp.Calculate().ToString("000.00"));


        }
    }
}
