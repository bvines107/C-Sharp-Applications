﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMICalculator
{
    class Scale
    {
        //protected member variable
        protected float weight;
        protected float height;

        //sets the member variables
        public void SetMeasurment(float weight, float height)
        {
            this.weight = weight;
            this.height = height;
        }
    }
}
