﻿namespace PingIPAddress
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPing = new MetroFramework.Controls.MetroButton();
            this.txtBox = new MetroFramework.Controls.MetroTextBox();
            this.lblBox = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // btnPing
            // 
            this.btnPing.Location = new System.Drawing.Point(75, 152);
            this.btnPing.Name = "btnPing";
            this.btnPing.Size = new System.Drawing.Size(113, 44);
            this.btnPing.TabIndex = 0;
            this.btnPing.Text = "Ping";
            this.btnPing.UseSelectable = true;
            this.btnPing.Click += new System.EventHandler(this.PingClicked);
            // 
            // txtBox
            // 
            // 
            // 
            // 
            this.txtBox.CustomButton.Image = null;
            this.txtBox.CustomButton.Location = new System.Drawing.Point(120, 1);
            this.txtBox.CustomButton.Name = "";
            this.txtBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBox.CustomButton.TabIndex = 1;
            this.txtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBox.CustomButton.UseSelectable = true;
            this.txtBox.CustomButton.Visible = false;
            this.txtBox.Lines = new string[0];
            this.txtBox.Location = new System.Drawing.Point(40, 108);
            this.txtBox.MaxLength = 32767;
            this.txtBox.Name = "txtBox";
            this.txtBox.PasswordChar = '\0';
            this.txtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBox.SelectedText = "";
            this.txtBox.SelectionLength = 0;
            this.txtBox.SelectionStart = 0;
            this.txtBox.ShortcutsEnabled = true;
            this.txtBox.Size = new System.Drawing.Size(180, 23);
            this.txtBox.TabIndex = 2;
            this.txtBox.UseSelectable = true;
            this.txtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblBox
            // 
            this.lblBox.AutoSize = true;
            this.lblBox.Location = new System.Drawing.Point(21, 74);
            this.lblBox.Name = "lblBox";
            this.lblBox.Size = new System.Drawing.Size(230, 19);
            this.lblBox.TabIndex = 3;
            this.lblBox.Text = "Enter Host Name or Website Address:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 219);
            this.Controls.Add(this.lblBox);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.btnPing);
            this.Name = "Form1";
            this.Text = "Ping an IP Address";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnPing;
        private MetroFramework.Controls.MetroTextBox txtBox;
        private MetroFramework.Controls.MetroLabel lblBox;
    }
}

