﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;

namespace PingIPAddress
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PingClicked(object sender, EventArgs e)
        {
           string name;

            try
            {
                name = Convert.ToString(txtBox.Text);

                //create a ping object 
                Ping ping = new Ping();
                //create the send method to get a response from the pinged device
                PingReply reply = ping.Send(txtBox.Text, 1000);
                //will display the results of the ping
                MessageBox.Show(reply.Status.ToString());


            }
            catch(Exception)
            {
                //if error occurs a message box will show
                MessageBox.Show("An Error Occured", "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                // finally statement will educate the user to enter in host name or website address
                MessageBox.Show("Enter in the host address or website address", "More Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtBox_MouseEnter(object sender, EventArgs e)
        {
           
        }
    }
}
